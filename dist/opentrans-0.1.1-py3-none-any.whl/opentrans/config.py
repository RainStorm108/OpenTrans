from dataclasses import dataclass, fields, field
from typing import Optional, Set
from pathlib import Path
import yaml

@dataclass
class Settings:
    target_lang: str = "English"
    ollama_model: str = "translategemma:4b"
    temperature: float = 0.1
    input_dir: Path = "./docs"
    output_dir: Path = "./translated_docs"
    cache_name_format: str = ".{}_cache.json"
    hash_algo: str = "SHA1"
    trasnlated_file_types: Set[str] = field(default_factory=lambda: {".md"})

    def update_from_dict(self, data: dict):
        """Update settings from a dictionary, ignoring extra keys."""
        valid_keys = {f.name for f in fields(self)}
        for key, value in data.items():
            if key in valid_keys:
                setattr(self, key, value)

settings = Settings()

def load_config(yaml_path: Optional[str] = None, **kwargs):
    """
    The 'Source of Truth' for updating settings.
    Call this in main.py to override defaults.
    """
    global settings
    if yaml_path:
        with open(yaml_path, 'r') as f:
            data = yaml.safe_load(f)
            settings.update_from_dict(data)
    
    if kwargs:
        settings.update_from_dict(kwargs)