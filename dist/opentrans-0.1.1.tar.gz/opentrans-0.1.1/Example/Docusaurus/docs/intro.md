---
sidebar_position: 1
title: Introduction
description: Getting started with the documentation.
---

# Welcome to DocTrans

This is a test file to verify that **Frontmatter** is protected. 

## Basics
When using `ollama`, ensure your model is pulled. You can check this by running [Ollama Web](https://ollama.com).

:::note
Placeholders like [[DOC_REF_0]] should not be translated by the LLM.
:::